<?php

$filename = "/var/www/gd-preload-values.php";
if (file_exists($filename)) {
    include_once($filename);
}
