<?php
define( 'GD_HMT_SERVICE_KEY', '30b0cf22-1d96-4d3a-9999-faf433dcbd53' );
define( 'GD_PLAN_NAME', 'Ultimate Managed WordPress' );
define( 'GD_CDN_FULLPAGE', TRUE );
define( 'GD_RUM_ENABLED', FALSE );
define( 'GD_CUSTOMER_ID', '376bb966-ae69-4559-aec6-8bb7b53824aa' );
define( 'GD_DC_ID', 'p3n' );
define( 'GD_GF_LICENSE_KEY', 'u720PZpDfA7A91L8tnZiqzD5bX4oIjdv' );
define( 'GD_MIGRATED_SITE', FALSE );
define( 'GD_TEMP_DOMAIN', '1hq.c4a.myftpupload.com' );
define( 'GD_CDN_ENABLED', TRUE );
define( 'GD_RESELLER', 508638 );
define( 'GD_ASAP_KEY', '39e58c433ee5d6501376b7daeba42d86' );
define( 'GD_SITE_TOKEN', '62157385-8e66-4dfd-967c-d989245b90bc' );
define( 'GD_VIP', '45.40.151.118' );
define( 'GD_NEXTGEN_ENABLED', FALSE );
define( 'GD_SITE_CREATED', 1688185126 );
define( 'GD_ACCOUNT_UID', 'ae24fa44-ce04-4604-b064-d9cbb7ad0d8b' );
